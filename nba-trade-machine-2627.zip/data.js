window.NBA_DATA = {
  "teams": [
    "Atlanta Hawks",
    "Boston Celtics",
    "Brooklyn Nets",
    "Charlotte Hornets",
    "Chicago Bulls",
    "Cleveland Cavaliers",
    "Dallas Mavericks",
    "Denver Nuggets",
    "Detroit Pistons",
    "Golden State Warriors",
    "Houston Rockets",
    "Indiana Pacers",
    "LA Clippers",
    "Los Angeles Lakers",
    "Memphis Grizzlies",
    "Miami Heat",
    "Milwaukee Bucks",
    "Minnesota Timberwolves",
    "New Orleans Pelicans",
    "New York Knicks",
    "Oklahoma City Thunder",
    "Orlando Magic",
    "Philadelphia 76ers",
    "Phoenix Suns",
    "Portland Trail Blazers",
    "Sacramento Kings",
    "San Antonio Spurs",
    "Toronto Raptors",
    "Utah Jazz",
    "Washington Wizards"
  ],
  "players": [
    {
      "name": "Giannis Antetokounmpo",
      "team": "Miami Heat",
      "salary": 58500000
    },
    {
      "name": "Klay Thompson",
      "team": "Miami Heat",
      "salary": 16000000
    },
    {
      "name": "Nick Richards",
      "team": "Miami Heat",
      "salary": 12000000
    },
    {
      "name": "LeBron James",
      "team": "Philadelphia 76ers",
      "salary": 30000000
    },
    {
      "name": "Jaylen Brown",
      "team": "Philadelphia 76ers",
      "salary": 55000000
    },
    {
      "name": "Victor Wembanyama",
      "team": "San Antonio Spurs",
      "salary": 16500000
    },
    {
      "name": "Luka Doncic",
      "team": "Los Angeles Lakers",
      "salary": 46000000
    },
    {
      "name": "Austin Reaves",
      "team": "Los Angeles Lakers",
      "salary": 13000000
    },
    {
      "name": "DeMar DeRozan",
      "team": "Denver Nuggets",
      "salary": 28000000
    },
    {
      "name": "Ja Morant",
      "team": "Portland Trail Blazers",
      "salary": 36000000
    },
    {
      "name": "LaMelo Ball",
      "team": "Minnesota Timberwolves",
      "salary": 30000000
    },
    {
      "name": "Julius Randle",
      "team": "Brooklyn Nets",
      "salary": 30000000
    },
    {
      "name": "Bradley Beal",
      "team": "LA Clippers",
      "salary": 16000000
    },
    {
      "name": "Tobias Harris",
      "team": "San Antonio Spurs",
      "salary": 24000000
    },
    {
      "name": "Ben Simmons",
      "team": "Sacramento Kings",
      "salary": 3500000
    },
    {
      "name": "Chet Holmgren",
      "team": "Oklahoma City Thunder",
      "salary": 15000000
    },
    {
      "name": "Shai Gilgeous-Alexander",
      "team": "Oklahoma City Thunder",
      "salary": 50000000
    },
    {
      "name": "Anthony Edwards",
      "team": "Minnesota Timberwolves",
      "salary": 50000000
    },
    {
      "name": "Jayson Tatum",
      "team": "Boston Celtics",
      "salary": 54000000
    },
    {
      "name": "Donovan Mitchell",
      "team": "Cleveland Cavaliers",
      "salary": 38000000
    },
    {
      "name": "Trae Young",
      "team": "Atlanta Hawks",
      "salary": 46000000
    },
    {
      "name": "Kevin Durant",
      "team": "Houston Rockets",
      "salary": 53000000
    },
    {
      "name": "Devin Booker",
      "team": "Phoenix Suns",
      "salary": 54000000
    },
    {
      "name": "Stephen Curry",
      "team": "Golden State Warriors",
      "salary": 59000000
    },
    {
      "name": "Cooper Flagg",
      "team": "Dallas Mavericks",
      "salary": 13000000
    },
    {
      "name": "AJ Dybantsa",
      "team": "Washington Wizards",
      "salary": 10000000
    },
    {
      "name": "Darryn Peterson",
      "team": "Utah Jazz",
      "salary": 9500000
    },
    {
      "name": "Cameron Boozer",
      "team": "Memphis Grizzlies",
      "salary": 9000000
    },
    {
      "name": "Caleb Wilson",
      "team": "Chicago Bulls",
      "salary": 8500000
    },
    {
      "name": "Mikel Brown Jr.",
      "team": "Brooklyn Nets",
      "salary": 8000000
    }
  ]
};
