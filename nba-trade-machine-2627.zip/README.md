# NBA Trade Machine 2026–27

Static GitHub Pages prototype for a multi-team NBA trade machine.

## Publish
Upload `index.html`, `style.css`, `app.js`, and `data.js` to the root of the `main` branch. Then enable GitHub Pages from Settings → Pages and publish from `main` / root.

## Important
This is a prototype. The displayed player list and salaries are illustrative and must not be treated as a complete official contract database. Expand/verify the dataset before using it for real CBA analysis.
